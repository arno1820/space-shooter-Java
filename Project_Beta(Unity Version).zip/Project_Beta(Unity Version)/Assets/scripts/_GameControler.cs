﻿using UnityEngine;
using System.Collections;

public class _GameControler : MonoBehaviour {

    public Camera mainCam;
    public GameObject background;
    public BoxCollider2D leftWall;
    public BoxCollider2D rightWall;
    public BoxCollider2D topWall;
    public BoxCollider2D bottomWall;
    public GameObject bullet;
    public GameObject player;
    private SpriteRenderer srBackground;
	
    // Use this for initialization
	void Start () {

        srBackground = background.GetComponent<SpriteRenderer>();
        srBackground.sprite.texture.filterMode = FilterMode.Point;
        
    }

    // Update is called once per frame
    void Update () {

        fitCamera();
        setBoundaries();

	}

    private void fitCamera()
    {
        double width = srBackground.sprite.bounds.size.x;
        double worldScreenHeight = Camera.main.orthographicSize *2.0;
        double worldScreenWidth = worldScreenHeight / Screen.height * Screen.width;
        double height = srBackground.sprite.bounds.size.y;

        background.transform.localScale = new Vector2((float)(worldScreenWidth / width), (float)(worldScreenHeight / height));

    }

    private void setBoundaries()
    {
        topWall.size = new Vector2(mainCam.ScreenToWorldPoint(new Vector3(Screen.width * 2f, 0f, 0f)).x, 1f);
        topWall.offset = new Vector2(0f, mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.height, 0f)).y + 0.5f);

        bottomWall.size = new Vector2( mainCam.ScreenToWorldPoint(new Vector3(Screen.width * 2f, 0f, 0f)).x, 1f);
        bottomWall.offset = new Vector2(0f, -1 * mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.height, 0f)).y - 0.5f);

        leftWall.size = new Vector2(1f, mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.height * 2f, 0f)).y);
        leftWall.offset = new Vector2(mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.width, 0f)).x - 0.5f, 0f);

        rightWall.size = new Vector2(1f, mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.height * 2f, 0f)).y);
        rightWall.offset = new Vector2(-1 * mainCam.ScreenToWorldPoint(new Vector3(0f, Screen.width, 0f)).x + 0.5f, 0f);

    }

    public GameObject createBullet(Vector2 position, float velocity)
    {
        GameObject b = GameObject.Instantiate(bullet);
        b.transform.position = position;
        b.GetComponent<Rigidbody2D>().velocity = new Vector2(velocity, 0f);
        return b;
    }



}
