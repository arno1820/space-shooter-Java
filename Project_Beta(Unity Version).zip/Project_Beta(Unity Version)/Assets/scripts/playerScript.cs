﻿using UnityEngine;
using System.Collections;

public class playerScript : MonoBehaviour {

    public _GameControler gc;

    public KeyCode up;
    public KeyCode down;
    public KeyCode forward;
    public KeyCode backward;
    public KeyCode shoot;
    // {+X, -X, +Y, -Y}
    private float[] speed = { 5, -2, 3, -3};
    private Rigidbody2D rB;
    private float cooldown = 0;

    // Use this for initialization
	void Start () {
        
        transform.position = new Vector3(-1 * gc.mainCam.ScreenToWorldPoint(new Vector3(Screen.width, 0f, 0f)).x
           + transform.localScale.x + 3, 0f, 0f);
        rB = GetComponent<Rigidbody2D>();

    }
	
	// Update is called once per frame
	void Update () {

       float X = gameObject.transform.position.x;
       float dt = Time.deltaTime;
       float Y = gameObject.transform.position.y;
        rB.drag = 0f;
        bool moved = false;

        if (Input.GetKey(up))
        {
            moved = true;
            rB.velocity = new Vector2(rB.velocity.x, speed[2]);
            //rB.AddForce(transform.up * speed[2]);
        }
        if (Input.GetKey(down))
        {
            moved = true;
            rB.velocity = new Vector2(rB.velocity.x, speed[3]);
            //rB.AddForce(transform.up * -speed[3]);
        }
        if (Input.GetKey(forward))
        {
            moved = true;
            rB.velocity = new Vector2(speed[0], rB.velocity.y);
            //rB.AddForce(transform.right * speed[1]);
        }
        if (Input.GetKey(backward))
        {
            moved = true;
            rB.velocity = new Vector2(speed[1], rB.velocity.y);
            //rB.AddForce(transform.right * -speed[0]);
        }
        if (Input.GetKey(shoot) && cooldown <= 0)
        {

            cooldown = 10;
            Sprite sp = GetComponent<SpriteRenderer>().sprite;
            float height = sp.bounds.max.y - sp.bounds.min.y;
            gc.GetComponent<_GameControler>().createBullet(new Vector2(sp.bounds.max.x, height / 2), 1);
        }
        if (!moved)
        {
            rB.velocity = new Vector2(0f, 0f);
        }
       

	}
}
