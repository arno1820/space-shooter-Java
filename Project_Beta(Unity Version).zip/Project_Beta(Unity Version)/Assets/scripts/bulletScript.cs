﻿using UnityEngine;
using System.Collections;

public class bulletScript : MonoBehaviour {

    _GameControler gc;
    private Rigidbody2D rB;

	// Use this for initialization
	void Start () {

        rB = GetComponent<Rigidbody2D>();

    }
	
	// Update is called once per frame
	void Update () {
	    
        

	}
}
