﻿using UnityEngine;
using System.Collections;

public enum behaviour
{
    IDLE, SHOOT, MOVE
};
